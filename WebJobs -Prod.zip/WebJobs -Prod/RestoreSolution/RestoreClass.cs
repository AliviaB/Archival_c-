﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;

namespace RestoreSolution
{
    class RestoreClass

    {
        List<ConfigTable> tableDetails;
        
        DataAccessClass dal = new DataAccessClass();

        public void getRestoreDetails()
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.UserID = ConfigurationManager.AppSettings["UserID"];
            builder.Password = ConfigurationManager.AppSettings["Password"];
            tableDetails = dal.readRestoreMasterTable();
            if (tableDetails.Count > 0)
            {
                foreach (ConfigTable table in tableDetails)
                {
                    try
                    {
                        if (table.DBType == "SQLDB")
                        prepareTableInputParamListDB(table);
                    else if (table.DBType == "SQLDW")
                        prepareTableInputParamListDW(table);
                    SqlConnection target;
                    builder.DataSource = table.ServerUrl;
                    builder.InitialCatalog = table.DataBaseName;
                    target = new SqlConnection(builder.ConnectionString);

                    dal.runRestoreProcess(table, target);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Exception: " + ex.Message.ToString());
                        break;
                    }

                }


            }
            else
                Console.WriteLine("No Table to restore..");
           
        }

        private void prepareTableInputParamListDB(ConfigTable conTable)
        {
            string spInputparameter = "SourceTableName=" + conTable.SourceSchemaName + "." + conTable.SourceTableName + "#|#ExportLocation=" + conTable.SourceUniqueName + "/" + conTable.SourceSchemaName + "." + conTable.SourceTableName + "/" + String.Format("{0:yyyyMMdd}", conTable.ArchInterval) + "/file.txt#|#";
            
            Console.WriteLine(spInputparameter);

            conTable.inputParams = spInputparameter;
            //tableDetails.Add(conTable);

        }
        private void prepareTableInputParamListDW(ConfigTable conTable)
        {  
            string spInputparameter = "SourceTableName=" + conTable.SourceSchemaName + "." + conTable.SourceTableName +"#|#ExportLocation=" + conTable.SourceUniqueName + "/" + conTable.SourceSchemaName + "." + conTable.SourceTableName + "/" + String.Format("{0:yyyyMMdd}", conTable.ArchInterval) + "#|#";
            
            Console.WriteLine(spInputparameter);

            conTable.inputParams = spInputparameter;
           // tableDetails.Add(conTable);

        }

    }
}
