﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace RestoreSolution
{
    public class DataAccessClass
    {
        List<ConfigTable> tableDetails = new List<ConfigTable>();


        public void runRestoreProcess( ConfigTable curentTable, SqlConnection target)
        {
            string exceStatus = string.Empty;
            string StatusMessage = string.Empty;
            DateTime Start = DateTime.Now;
            DateTime end = Start;


            try
            {


                using (target)
                {

                    SqlCommand cmd = null;
                    target.Open();
                    
                    if (curentTable.DBType == "SQLDB")
                         cmd = new SqlCommand("dataArchival.usp_loadDataToDB", target);
                    else if (curentTable.DBType == "SQLDW")
                        cmd = new SqlCommand("dataArchival.usp_restoreDataToDW", target);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(
                        new SqlParameter("@inputParam", SqlDbType.VarChar, 1000));
                    cmd.Parameters["@inputParam"].Value = curentTable.inputParams;
                    cmd.Parameters.Add(
                        new SqlParameter("@statusMessage", SqlDbType.VarChar, 128));
                    cmd.Parameters.Add(
                        new SqlParameter("@execStatus", SqlDbType.VarChar, 10));
                    cmd.Parameters["@execStatus"].Direction = ParameterDirection.Output;
                    cmd.Parameters["@statusMessage"].Direction = ParameterDirection.Output;
                    cmd.CommandTimeout = Convert.ToInt32(ConfigurationManager.AppSettings["Timeout"]);
                    cmd.ExecuteNonQuery();
                    StatusMessage = cmd.Parameters["@statusMessage"].Value.ToString();
                    exceStatus = cmd.Parameters["@execStatus"].Value.ToString();
                    Console.WriteLine(exceStatus);
                    end = DateTime.Now;



                    target.Close();


                    if (exceStatus != "0")
                        throw new System.ArgumentException(StatusMessage);
                }


            }


            catch (SqlException e)
            {
                exceStatus = "1";
                StatusMessage = e.Message;
                end = DateTime.Now;
                throw e;
                
            }
            finally
            {
                updateRestoreStatus(curentTable, exceStatus, StatusMessage, Start, end);

            }

        }

        public void updateRestoreStatus(ConfigTable curntTable,  string execStatus, string StatusMsg, DateTime Start, DateTime End)
        {

            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
           
            var connectionString = ConfigurationManager.ConnectionStrings["BaseConnection"].ConnectionString;
            builder.ConnectionString = connectionString;
            SqlConnection Base = new SqlConnection(builder.ConnectionString);

            using (Base)
            {
                string query = "Insert into dataArchival.ArchivalRunLog" +
                "(TableId,ArchInterval,ActivityType,RunStartDatetime,RunEndDatetime,RunStatus,RunMessage)" +
                    "Values(@tableid,@archivalIntrval,@ActctType,@RunStart,@RunEnd,@Status,@Message)";
             //   var strInterval = inputParam.Substring(inputParam.IndexOf("#StartDate=") + 11, 10);
                using (SqlCommand comm = new SqlCommand(query, Base))
                {
                    comm.Parameters.Add(
                           new SqlParameter("@tableid", SqlDbType.Int));
                    comm.Parameters["@tableid"].Value = curntTable.TableId;
                    comm.Parameters.Add(
                          new SqlParameter("@archivalIntrval", SqlDbType.VarChar, 10));
                    comm.Parameters["@archivalIntrval"].Value = String.Format("{0:yyyy-MM-dd}", curntTable.ArchInterval);
                    comm.Parameters.Add(
                          new SqlParameter("@ActctType", SqlDbType.VarChar, 10));
                    comm.Parameters["@ActctType"].Value = "Restore";
                    comm.Parameters.Add(
                         new SqlParameter("@RunStart", SqlDbType.DateTime2));
                    comm.Parameters["@RunStart"].Value = Start;
                    comm.Parameters.Add(
                            new SqlParameter("@RunEnd", SqlDbType.DateTime2));
                    comm.Parameters["@RunEnd"].Value = End;
                    comm.Parameters.Add(
                            new SqlParameter("@Status", SqlDbType.VarChar, 1));
                    comm.Parameters["@Status"].Value = execStatus;
                    comm.Parameters.Add(
                            new SqlParameter("@Message", SqlDbType.VarChar, 256));
                    comm.Parameters["@Message"].Value = StatusMsg;
                    Base.Open();
                    comm.ExecuteNonQuery();
                    Base.Close();
                }
                // 
                string query2 = " MERGE dataArchival.ArchivalStatus AS target USING(SELECT @tblID, @archivalIntrval, @restStatus,@restReqInd) AS source(TableID, ArchInterval, RestoreStatus,RestoreRequestInd)"
                                + " ON(target.TableId = source.TableId and target.ArchInterval = source.ArchInterval)"
                                + " WHEN MATCHED THEN"
                                + " UPDATE SET RestoreStatus = source.RestoreStatus, RestoreRequestInd = source.RestoreRequestInd"
                                + " WHEN NOT MATCHED THEN"
                                + " INSERT(TableID, ArchInterval, RestoreStatus,RestoreRequestInd)"
                                + " VALUES(source.TableId, source.ArchInterval, source.RestoreStatus,source.RestoreRequestInd); ";

                using (SqlCommand cmd = new SqlCommand(query2, Base))
                {
                    //cmd.Connection = Base;
                    cmd.Parameters.Add(
                           new SqlParameter("@tblID", SqlDbType.Int));
                    cmd.Parameters["@tblID"].Value = curntTable.TableId;
                    cmd.Parameters.Add(
                          new SqlParameter("@archivalIntrval", SqlDbType.VarChar, 10));
                    cmd.Parameters["@archivalIntrval"].Value = String.Format("{0:yyyy-MM-dd}", curntTable.ArchInterval);
                    cmd.Parameters.Add(
                          new SqlParameter("@restStatus", SqlDbType.VarChar, 10));
                    cmd.Parameters["@restStatus"].Value = execStatus == "0" ? "1" : "0"; // DB undestands 0 as failure. 1 as success.
                    cmd.Parameters.Add(
                          new SqlParameter("@restReqInd", SqlDbType.VarChar, 10));
                    cmd.Parameters["@restReqInd"].Value = execStatus ;
                    Base.Open();
                    cmd.ExecuteNonQuery();
                    Base.Close();
                }
            }

        }


        public List<ConfigTable> readRestoreMasterTable()
        {

            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

                var connectionString = ConfigurationManager.ConnectionStrings["BaseConnection"].ConnectionString;
                builder.ConnectionString = connectionString;
                SqlConnection connection = new SqlConnection(builder.ConnectionString);

                using (connection)
                {
                    Console.WriteLine("\nRestore Solution Runlog:");
                    Console.WriteLine("=========================================\n");

                    connection.Open();

                    SqlCommand cmd = new SqlCommand("select m.TableId,"
                                               +"SourceUniqueName,"
                                               +"ServerUrl,         "
                                               +"DataBaseName,      "
                                               +"DBType,            "
                                               +"SourceTableName,   "
                                               +"SourceSchemaName,  "
                                               +"ArchFrequency,     "
                                               +"st.ArchInterval    "
                                               +"from dataArchival.ArchivalMaster m           " 
                                               +"inner                                        "
                                               +"join dataArchival.ArchivalSourceConfig s     "
                                               +"on m.SourceId = s.SourceId                   "
                                               +"inner                                        "
                                               +"join dataArchival.ArchivalStatus st          "
                                               +"on st.TableId = m.TableId                    "
                                               +"where m.ActiveInd = 1                        "
                                               +"and st.ArchStatus = '1'                      "
                                               +"and st.PurgeStatus = '1'                     "
                                               +"and st.RestoreRequestInd = '1'               "
                                               +"order by s.SourceId", connection);
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ConfigTable configData = new ConfigTable()
                            {
                                TableId = (int)reader["TableId"],
                                SourceUniqueName = (string)reader["SourceUniqueName"],
                                ServerUrl = (string)reader["ServerUrl"],
                                DataBaseName = (string)reader["DataBaseName"],
                                DBType = (string)reader["DBType"],
                                SourceTableName = (string)reader["SourceTableName"],
                                SourceSchemaName = (string)reader["SourceSchemaName"],
                                ArchFrequency = (string)reader["ArchFrequency"],
                                ArchInterval = Convert.ToDateTime(reader["ArchInterval"])
                            };
                            tableDetails.Add(configData);
                        }
                    }

                    //connection.Close();
                }

            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
            }


            return tableDetails;
        }

        
    }
}

