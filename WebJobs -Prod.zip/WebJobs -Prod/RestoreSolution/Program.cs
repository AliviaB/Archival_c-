﻿using System;

namespace RestoreSolution
{
    class Program
    {
        static void Main(string[] args)
        {
            RestoreClass rc = new RestoreClass();
            rc.getRestoreDetails();
            Console.WriteLine("Execution completed");
            
        }
    }
}
