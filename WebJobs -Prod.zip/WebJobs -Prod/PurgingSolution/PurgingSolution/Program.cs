﻿using System;

namespace PurgingSolution
{
    class Program
    {
        static void Main(string[] args)
        {
            
            PurgeDataClass purge = new PurgeDataClass();
            purge.readAllData();
        }
    }
}
