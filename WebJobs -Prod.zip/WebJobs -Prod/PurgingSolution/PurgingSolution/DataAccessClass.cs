﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


namespace PurgingSolution
{
    class DataAccessClass
    {

        public List<ConfigTable> readArchivalMasterTable()
        {
            List<ConfigTable> tableDetails = new List<ConfigTable>();

            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                
                var connectionString = ConfigurationManager.ConnectionStrings["BaseConnection"].ConnectionString;
                builder.ConnectionString = connectionString;
                SqlConnection connection = new SqlConnection(builder.ConnectionString);

                using (connection)
                {
                    Console.WriteLine("\nPurge Solution RunLog:");
                    Console.WriteLine("=========================================\n");

                    connection.Open();

                    SqlCommand cmd = new SqlCommand("select TableId,SourceUniqueName, ServerUrl, DataBaseName, DBType, SourceTableName,PurgeIntervalLast, SourceSchemaName, ArchFrequency," +
                        " PurgeRetentionPeriod, ArchSourceTSField,PartitionedInd from dataArchival.ArchivalMaster m inner join dataArchival.ArchivalSourceConfig s" +
                        " on m.SourceId = s.SourceId where m.ActiveInd = 1 order by s.SourceId", connection);
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ConfigTable configData = new ConfigTable()
                            {
                                TableId = (int)reader["TableId"],
                                SourceUniqueName = (string)reader["SourceUniqueName"],
                                ServerUrl = (string)reader["ServerUrl"],
                                DataBaseName = (string)reader["DataBaseName"],
                                DBType = (string)reader["DBType"],
                                SourceTableName = (string)reader["SourceTableName"],
                                SourceSchemaName = (string)reader["SourceSchemaName"],
                                ArchFrequency = (string)reader["ArchFrequency"],
                                PurgeRetentionPeriod = (int)reader["PurgeRetentionPeriod"],
                                ArchSourceTSField = (string)reader["ArchSourceTSField"],
                                PurgeIntervalLast = Convert.ToDateTime(reader["PurgeIntervalLast"]),
                                Partitioned = (string)(reader["PartitionedInd"])
                            };
                            tableDetails.Add(configData);
                        }
                    }

                    //connection.Close();
                }

            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
            }


            return tableDetails;
        }

        public bool getArchivalStatus(string archInterval, int TableID)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

            var connectionString = ConfigurationManager.ConnectionStrings["BaseConnection"].ConnectionString;
            builder.ConnectionString = connectionString;
            SqlConnection Base = new SqlConnection(builder.ConnectionString);
            string Status="";

            using (Base)
            {
                string query = "SELECT ArchStatus from [dataArchival].[ArchivalStatus]" +
                                   "where TableId=@tableid and ArchInterval =@archivalIntrval";
                //Console.WriteLine(query);
                
                using (SqlCommand comm = new SqlCommand(query, Base))
                {
                    comm.Parameters.Add(
                           new SqlParameter("@tableid", SqlDbType.Int));
                    comm.Parameters["@tableid"].Value = TableID;
                    comm.Parameters.Add(
                          new SqlParameter("@archivalIntrval", SqlDbType.VarChar, 10));
                    comm.Parameters["@archivalIntrval"].Value = archInterval;
                    
                    Base.Open();
                    SqlDataReader reader = comm.ExecuteReader();
                    if (reader.Read())
                       Status  = String.Format("{0}", reader["ArchStatus"]);


                    
                    
                    Base.Close();
                }

            }
            if (Status == "1")
                return true;
            else
                return false;
        }

        public void runPurgeProcess(string item, ConfigTable currentTable, SqlConnection target)
        {
            string exceStatus = string.Empty;
            string StatusMessage = string.Empty;
            DateTime Start = DateTime.Now;
            DateTime end = Start;


            try
            {


                using (target)
                {
                    target.Open();
                    SqlCommand cmd = null;
                    if (currentTable.Partitioned=="1" && currentTable.DBType == "SQLDB" )
                    { cmd= new SqlCommand("dataArchival.usp_purgeDataPartition", target); }
                    else if (currentTable.Partitioned == "0" && currentTable.DBType == "SQLDB")
                    {
                        cmd = new SqlCommand("dataArchival.usp_purgeDataBatch", target);
                    }
                    else if (currentTable.Partitioned == "1" && currentTable.DBType == "SQLDW")
                    {
                        cmd = new SqlCommand("dataArchival.usp_purgeDataPartitionedTable", target);
                    }
                    else if (currentTable.Partitioned == "0" && currentTable.DBType == "SQLDW")
                    {
                        cmd = new SqlCommand("dataArchival.usp_purgeData", target);
                    }
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(
                        new SqlParameter("@inputParam", SqlDbType.VarChar, 1000));
                    cmd.Parameters["@inputParam"].Value = item;
                    cmd.Parameters.Add(new SqlParameter("@execStatus", SqlDbType.VarChar, 10){ Direction = ParameterDirection.Output });
                    cmd.Parameters.Add(new SqlParameter("@statusMessage", SqlDbType.VarChar, 1000){ Direction = ParameterDirection.Output });

                    cmd.CommandTimeout = Convert.ToInt32(ConfigurationManager.AppSettings["Timeout"]);
                    cmd.ExecuteNonQuery();
                    StatusMessage = cmd.Parameters["@statusMessage"].Value.ToString();
                    exceStatus = cmd.Parameters["@execStatus"].Value.ToString();
                   // Console.WriteLine(cmd.CommandText.ToString());
                    Console.WriteLine(exceStatus);
                   // Console.WriteLine(StatusMessage);
                    end = DateTime.Now;



                    target.Close();


                    if (exceStatus != "0")
                        throw new System.ArgumentException(StatusMessage);
                }


            }


            catch (SqlException e)
            {
                exceStatus = "1";
                end = DateTime.Now;
                StatusMessage = e.Message;
                throw e;
            }
            finally
            {
                updatePurgeStatus(currentTable, item, exceStatus, StatusMessage, Start, end);

            }

        }

        public void updatePurgeStatus(ConfigTable curntTable, string inputParam, string execStatus, string StatusMsg, DateTime Start, DateTime End)
        {

            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            
            var connectionString = ConfigurationManager.ConnectionStrings["BaseConnection"].ConnectionString;
            builder.ConnectionString = connectionString;
            SqlConnection Base = new SqlConnection(builder.ConnectionString);

            using (Base)
            {
                string query = "Insert into dataArchival.ArchivalRunLog" +
                "(TableId,ArchInterval,ActivityType,RunStartDatetime,RunEndDatetime,RunStatus,RunMessage)" +
                    "Values(@tableid,@archivalIntrval,@ActctType,@RunStart,@RunEnd,@Status,@Message)";
                var strInterval = curntTable.Partitioned == "1" ? inputParam.Substring(inputParam.IndexOf("#ArchPeriod=") + 12, 10) : inputParam.Substring(inputParam.IndexOf("#StartDate=") + 11, 10);

                using (SqlCommand comm = new SqlCommand(query, Base))
                {
                    comm.Parameters.Add(
                           new SqlParameter("@tableid", SqlDbType.Int));
                    comm.Parameters["@tableid"].Value = curntTable.TableId;
                    comm.Parameters.Add(
                          new SqlParameter("@archivalIntrval", SqlDbType.VarChar, 10));
                    comm.Parameters["@archivalIntrval"].Value = strInterval;
                    comm.Parameters.Add(
                          new SqlParameter("@ActctType", SqlDbType.VarChar, 10));
                    comm.Parameters["@ActctType"].Value = "Purge";
                    comm.Parameters.Add(
                         new SqlParameter("@RunStart", SqlDbType.DateTime2));
                    comm.Parameters["@RunStart"].Value = Start;
                    comm.Parameters.Add(
                            new SqlParameter("@RunEnd", SqlDbType.DateTime2));
                    comm.Parameters["@RunEnd"].Value = End;
                    comm.Parameters.Add(
                            new SqlParameter("@Status", SqlDbType.VarChar, 1));
                    comm.Parameters["@Status"].Value = execStatus;
                    comm.Parameters.Add(
                            new SqlParameter("@Message", SqlDbType.VarChar, 256));
                    comm.Parameters["@Message"].Value = StatusMsg;
                    Base.Open();
                    comm.ExecuteNonQuery();
                    Base.Close();
                }
                // 
                string query2 = " MERGE dataArchival.ArchivalStatus AS target USING(SELECT @tblID, @archivalIntrval, @purgeStatus) AS source(TableID, ArchInterval, PurgeStatus)"
                                + " ON(target.TableId = source.TableId and target.ArchInterval = source.ArchInterval)"
                                + " WHEN MATCHED THEN"
                                + " UPDATE SET PurgeStatus = source.PurgeStatus"
                                + " WHEN NOT MATCHED THEN"
                                + " INSERT(TableID, ArchInterval, PurgeStatus)"
                                + " VALUES(source.TableId, source.ArchInterval, source.PurgeStatus); ";

                using (SqlCommand cmd = new SqlCommand(query2, Base))
                {
                    //cmd.Connection = Base;
                    cmd.Parameters.Add(
                           new SqlParameter("@tblID", SqlDbType.Int));
                    cmd.Parameters["@tblID"].Value = curntTable.TableId;
                    cmd.Parameters.Add(
                          new SqlParameter("@archivalIntrval", SqlDbType.VarChar, 10));
                    cmd.Parameters["@archivalIntrval"].Value = strInterval;
                    cmd.Parameters.Add(
                          new SqlParameter("@purgeStatus", SqlDbType.VarChar, 10));
                    cmd.Parameters["@purgeStatus"].Value = execStatus == "0" ? "1" : "0"; // DB undestands 0 as failure. 1 as success.
                    Base.Open();
                    cmd.ExecuteNonQuery();
                    Base.Close();
                }
            }

        }
        public void updateArchivalMasterTable(string ArchIntervalLast, int TableId)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            
            var connectionString = ConfigurationManager.ConnectionStrings["BaseConnection"].ConnectionString;
            builder.ConnectionString = connectionString;
            SqlConnection Connection = new SqlConnection(builder.ConnectionString);
            string query = "UPDATE dataArchival.ArchivalMaster SET PurgeIntervalLast= @LastDt WHERE TableId= @id";

            using (SqlCommand command = new SqlCommand(query, Connection))


                try
                {
                    // open the connection, execute, etc
                    command.Parameters.Add(
                        new SqlParameter("@LastDt", SqlDbType.VarChar, 10));
                    command.Parameters["@LastDt"].Value = ArchIntervalLast;// String.Format("{0:yyyy-MM-dd}", ArchIntervalLast);
                    command.Parameters.Add(
                        new SqlParameter("@id", SqlDbType.Int));
                    command.Parameters["@id"].Value = TableId;
                    // p.Add(new SqlParameter("@", ArchIntervalLast));
                    // p.Add(new SqlParameter("@id", TableId));

                    Connection.Open();
                    command.ExecuteNonQuery();
                    command.Parameters.Clear();
                    Connection.Close();
                    Console.WriteLine("Source Updated");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message.ToString());
                }
        }
    }
}
