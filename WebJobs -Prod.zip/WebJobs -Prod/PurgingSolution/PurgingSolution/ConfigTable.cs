﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PurgingSolution
{
    class ConfigTable
    {

        public int TableId { get; set; }
        public string SourceUniqueName { get; set; }
        public string ServerUrl { get; set; }
        public string DataBaseName { get; set; }
        public string DBType { get; set; }



        public string SourceTableName { get; set; }
        public string SourceSchemaName { get; set; }


        public string ArchFrequency { get; set; }
        public int PurgeRetentionPeriod { get; set; }
        public string ArchSourceTSField { get; set; }

        public string Partitioned { get; set; }

        public DateTime PurgeIntervalLast { get; set; }
        public DateTime dateToUpdate { get; set; }
        public bool isExceptionFound { get; set; }
        public List<string> inputParams { get; set; }
        
    }
}
