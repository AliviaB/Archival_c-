﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace PurgingSolution
{
    class PurgeDataClass
    {
        List<ConfigTable> tableDetails;
        List<ConfigTable> eligibleTableListforAchival;
        List<ConfigTable> updateTable = new List<ConfigTable>();

        DataAccessClass dal = new DataAccessClass();

        public void readAllData()
        {


            tableDetails = dal.readArchivalMasterTable();
            if (tableDetails != null && tableDetails.Count > 0)
            {
                eligibleTableListforAchival = new List<ConfigTable>();
                getArchivedEligibleTableList(tableDetails);
            }
        }

        private void getArchivedEligibleTableList(List<ConfigTable> tableList)
        {

            var firstDayOfMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            foreach (ConfigTable table in tableDetails)
            {
                if (table.PurgeIntervalLast.Date.AddMonths(table.PurgeRetentionPeriod) < firstDayOfMonth.Date)

                {
                    if (table.ArchFrequency == "MONTH")
                    {
                        if(table.DBType=="SQLDW")
                        { 
                        prepareTableInputParamListDW(table);
                        }
                        else if (table.DBType == "SQLDB")
                        {
                            prepareTableInputParamListDB(table);
                        }
                    }
                }

            }

           foreach (ConfigTable elgbletable in eligibleTableListforAchival)
            {
                processTable(elgbletable);
            }



        }



        private void prepareTableInputParamListDW(ConfigTable conTable)
        {
            var inputparam = new List<string>();
            
            var todaysDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            var retentionDate = todaysDate.AddMonths(-conTable.PurgeRetentionPeriod);
            var tillDateToArchive = retentionDate.AddMonths(-1);
            var differceinMonth = ((tillDateToArchive.Year - conTable.PurgeIntervalLast.Year) * 12) + tillDateToArchive.Month - conTable.PurgeIntervalLast.Month;
            for (int count = 1; count <= differceinMonth; count++)
            {

                var startDate = conTable.PurgeIntervalLast.AddMonths(count);
                var endDate = startDate.AddMonths(1).AddDays(-1);
                if (conTable.Partitioned == "1")
                { 
                string spInputparameter = "SourceTableName=" + conTable.SourceSchemaName + "." + conTable.SourceTableName + "#|#ArchSourceTSField="
                    + conTable.ArchSourceTSField + "#|#ArchPeriod=" + String.Format("{0:yyyy-MM-dd}", startDate) + "#|#";
                    
                inputparam.Add(spInputparameter);
                Console.WriteLine(spInputparameter);
                }
                else if (conTable.Partitioned == "0")
                {
                    string spInputparameter = "SourceTableName=" + conTable.SourceSchemaName + "." + conTable.SourceTableName + "#|#ArchSourceTSField="
                        + conTable.ArchSourceTSField + "#|#StartDate=" + String.Format("{0:yyyy-MM-dd}", startDate) + "#|#EndDate=" + String.Format("{0:yyyy-MM-dd}", endDate) + "#|#ArchFrequency=" + conTable.ArchFrequency + "#|#";
                    inputparam.Add(spInputparameter);
                    Console.WriteLine(spInputparameter);
                }
            }
            conTable.inputParams = inputparam;
            
            eligibleTableListforAchival.Add(conTable);

        }

        private void prepareTableInputParamListDB(ConfigTable conTable)
        {
            var inputparam = new List<string>();
            var todaysDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            var retentionDate = todaysDate.AddMonths(-conTable.PurgeRetentionPeriod);
            var tillDateToArchive = retentionDate.AddMonths(-1);
            var differceinMonth = ((tillDateToArchive.Year - conTable.PurgeIntervalLast.Year) * 12) + tillDateToArchive.Month - conTable.PurgeIntervalLast.Month;
            for (int count = 1; count <= differceinMonth; count++)
            {

                var startDate = conTable.PurgeIntervalLast.AddMonths(count);
                var endDate = startDate.AddMonths(1).AddDays(-1);

                if (conTable.Partitioned == "1")
                {
                    string spInputparameter = "SourceTableName=" + conTable.SourceSchemaName + "." + conTable.SourceTableName + "#|#ArchSourceTSField="
                        + conTable.ArchSourceTSField + "#|#ArchPeriod=" + String.Format("{0:yyyy-MM-dd}", startDate) + "#|#";
                    inputparam.Add(spInputparameter);
                    Console.WriteLine(spInputparameter);
                }
                else if (conTable.Partitioned == "0")
                {
                    string spInputparameter = "SourceTableName=" + conTable.SourceSchemaName + "." + conTable.SourceTableName + "#|#ArchSourceTSField="
                    + conTable.ArchSourceTSField + "#|#StartDate=" + String.Format("{0:yyyy-MM-dd}", startDate) + "#|#EndDate=" + String.Format("{0:yyyy-MM-dd}", endDate) + "#|#";
                    inputparam.Add(spInputparameter);
                    Console.WriteLine(spInputparameter);
                }
            }
            conTable.inputParams = inputparam;
            eligibleTableListforAchival.Add(conTable);

        }

        private void processTable(ConfigTable tblArchive)
        {

            if (tblArchive.inputParams.Count > 0)
            {
                DataAccessClass DB = new DataAccessClass();
                int index = 0;
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                
                builder.UserID = ConfigurationManager.AppSettings["UserID"];
                builder.Password = ConfigurationManager.AppSettings["Password"];
                
                
                SqlConnection target;
                

                target = new SqlConnection(builder.ConnectionString);


                foreach (string inputString in tblArchive.inputParams)
                {
                    try
                    {
                                builder.DataSource = tblArchive.ServerUrl;
                                builder.InitialCatalog = tblArchive.DataBaseName;
                                target = new SqlConnection(builder.ConnectionString);
                                
                            

                        string startdate= tblArchive.Partitioned=="1"? inputString.Substring(inputString.IndexOf("#ArchPeriod=") + 12, 10):inputString.Substring(inputString.IndexOf("#StartDate=") + 11, 10);



                        if (DB.getArchivalStatus(startdate, tblArchive.TableId))
                        {
                            DB.runPurgeProcess(inputString, tblArchive, target);


                            index++;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Exception: " + ex.Message.ToString());
                        break;
                    }

                }
                if (index > 0)
                {
                    var lastSucfulInputParam = tblArchive.inputParams[index - 1];
                    var lstArchiveDate = tblArchive.Partitioned == "1" ? lastSucfulInputParam.Substring(lastSucfulInputParam.IndexOf("#ArchPeriod=") + 12, 10) : lastSucfulInputParam.Substring(lastSucfulInputParam.IndexOf("#StartDate=") + 11, 10);
                    //var lstArchiveDate = lastSucfulInputParam.Substring(lastSucfulInputParam.IndexOf("#StartDate=") + 11, 10);
                   dal.updateArchivalMasterTable(lstArchiveDate, tblArchive.TableId);

                }
            }
        }




    }

}