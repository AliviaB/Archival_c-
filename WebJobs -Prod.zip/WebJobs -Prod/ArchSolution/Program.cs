﻿using System;

namespace ArchSolution
{
    class Program
    {
        static void Main(string[] args)
        {
            ReadDataClass rdData = new ReadDataClass();
            rdData.fetchAllData();

           
            Console.WriteLine("Execution completed");
            //Console.WriteLine("\n\n Press any key to exit");
            //Console.ReadLine();
        }
    }
}
