﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;


namespace ArchSolution
{
    class ReadDataClass
    {
        List<ConfigTable> tableDetails;
        List<ConfigTable> eligibleTableListforAchival;
        List<ConfigTable> updateTable = new List<ConfigTable>();

        DataAccessClass dal = new DataAccessClass();



        public void fetchAllData()
        {


            tableDetails = dal.readArchivalMasterTable();
            if (tableDetails != null && tableDetails.Count() > 0)
            {
                eligibleTableListforAchival = new List<ConfigTable>();
                getArchivedEligibleTableList(tableDetails);
            }
        }

        private void getArchivedEligibleTableList(List<ConfigTable> tableList)
        {

            var firstDayOfMonth = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            foreach (ConfigTable table in tableDetails)
            {
                if (table.ArchIntervalLast.Date.AddMonths(table.ArchRetentionPeriod) < firstDayOfMonth.Date)

                {
                    if (table.ArchFrequency == "MONTH")
                    {
                        prepareTableInputParamList(table);
                    }
                }

            }

            foreach (ConfigTable elgbletable in eligibleTableListforAchival)
            {
                processTable(elgbletable);
            }

        }

        private void processTable(ConfigTable tblArchive)
        {

            if (tblArchive.inputParams.Count() > 0)
            {
                DataAccessClass DB = new DataAccessClass();
                int index = 0;
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                //builder.DataSource = "aznldatalakedbdv01.database.windows.net";
                builder.UserID = ConfigurationManager.AppSettings["UserID"];
                builder.Password = ConfigurationManager.AppSettings["Password"];
                // builder.InitialCatalog = "datalakedwdv01";
                String DBName = "";



                foreach (string inputString in tblArchive.inputParams)
                {
                    try
                    {
                        SqlConnection target;
                        builder.DataSource = tblArchive.ServerUrl;
                        builder.InitialCatalog = tblArchive.DataBaseName;

                        target = new SqlConnection(builder.ConnectionString);
                        if (tblArchive.DBType == "SQLDW")
                        {
                            if (DBName != tblArchive.DataBaseName)
                            {
                                builder.DataSource = tblArchive.ServerUrl;
                                builder.InitialCatalog = tblArchive.DataBaseName;
                                target = new SqlConnection(builder.ConnectionString);
                                DBName = tblArchive.DataBaseName;
                            }
                            DB.runArchivalProcess(inputString, tblArchive, target);

                        }
                        else if (tblArchive.DBType == "SQLDB")
                        {
                            ADF dfactory = new ADF();
                            dfactory.initiate(inputString, tblArchive);
                        }
                        index++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Exception: " + ex.Message.ToString());
                        break;
                    }

                }
                if (index > 0)
                {
                    var lastSucfulInputParam = tblArchive.inputParams[index - 1];
                    var lstArchiveDate = lastSucfulInputParam.Substring(lastSucfulInputParam.IndexOf("#StartDate=") + 11, 10);
                    dal.updateArchivalMasterTable(lstArchiveDate, tblArchive.TableId);

                }
            }
        }



        /// <summary>
        /// Preapare monthwise archival startdate and endDate for each table
        /// </summary>
        /// <param name="conTable"></param>
        private void prepareTableInputParamList(ConfigTable conTable)
        {
            var inputparam = new List<string>();
            var todaysDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            var retentionDate = todaysDate.AddMonths(-conTable.ArchRetentionPeriod);
            var tillDateToArchive = retentionDate.AddMonths(-1);
            var differceinMonth = ((tillDateToArchive.Year - conTable.ArchIntervalLast.Year) * 12) + tillDateToArchive.Month - conTable.ArchIntervalLast.Month;
            for (int count = 1; count <= differceinMonth; count++)
            {

                var startDate = conTable.ArchIntervalLast.AddMonths(count);
                var endDate = startDate.AddMonths(1).AddDays(-1);
                string spInputparameter = "SourceTableName=" + conTable.SourceSchemaName + "." + conTable.SourceTableName + "#|#ArchSourceTSField="
                    + conTable.ArchSourceTSField + "#|#StartDate=" + String.Format("{0:yyyy-MM-dd}", startDate) + "#|#EndDate=" + String.Format("{0:yyyy-MM-dd}", endDate) + "#|#ExportLocation=" + conTable.SourceUniqueName + "/" + conTable.SourceSchemaName + "." + conTable.SourceTableName + "/" + String.Format("{0:yyyyMMdd}", startDate) + "#|#";
                inputparam.Add(spInputparameter);
                Console.WriteLine(spInputparameter);
            }
            conTable.inputParams = inputparam;
            eligibleTableListforAchival.Add(conTable);

        }


    }
}





