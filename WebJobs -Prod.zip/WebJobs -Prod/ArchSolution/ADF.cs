﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Rest;
using Microsoft.Azure.Management.ResourceManager;
using Microsoft.Azure.Management.DataFactory;
using Microsoft.Azure.Management.DataFactory.Models;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Configuration;


namespace ArchSolution
{
    class ADF
    {
        // Set variables
        string tenantID = ConfigurationManager.AppSettings["tenantID"];
        string applicationId = ConfigurationManager.AppSettings["applicationId"];
        string authenticationKey = ConfigurationManager.AppSettings["authenticationKey"];
        string subscriptionId = ConfigurationManager.AppSettings["subscriptionId"];
        string resourceGroup = ConfigurationManager.AppSettings["resourceGroup"];

        string dataFactoryName = ConfigurationManager.AppSettings["dataFactoryName"];

        string pipelineName = ConfigurationManager.AppSettings["pipelineName"];   // name of the pipeline

        public void initiate(string inputString, ConfigTable tblArch)
        {
            string StartDate, EndDate, ExportLocation, UserName, password;
            // Authenticate and create a data factory management client
            StartDate = inputString.Substring(inputString.IndexOf("#StartDate=") + 11, 10);
            EndDate = inputString.Substring(inputString.IndexOf("#EndDate=") + 9, 10);
            // Console.WriteLine(inputString.Substring(inputString.IndexOf("#ExportLocation=") + 16, inputString.Length ));
            DateTime newFormat = DateTime.ParseExact(StartDate, "yyyy'-'MM'-'dd", null);
            ExportLocation = tblArch.SourceUniqueName + "/" + tblArch.SourceSchemaName + "." + tblArch.SourceTableName + "/" + String.Format("{0:yyyyMMdd}", newFormat);
            UserName = ConfigurationManager.AppSettings["UserID"];
            password = ConfigurationManager.AppSettings["Password"];
            var context = new AuthenticationContext("https://login.windows.net/" + tenantID);
            ClientCredential cc = new ClientCredential(applicationId, authenticationKey);
            AuthenticationResult result = context.AcquireTokenAsync("https://management.azure.com/", cc).Result;
            ServiceClientCredentials cred = new TokenCredentials(result.AccessToken);
            var client = new     DataFactoryManagementClient(cred) { SubscriptionId = subscriptionId };

            // Create a pipeline run
            Console.WriteLine("Creating pipeline run...");
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { "SourceTableName", tblArch.SourceSchemaName + "." + tblArch.SourceTableName },
                { "ArchSourceTSField", tblArch.ArchSourceTSField },
                { "StartDate", StartDate },
                { "EndDate", EndDate },
                { "ExportLocation", ExportLocation },
                { "ServerName", tblArch.ServerUrl },
                { "DataBaseName", tblArch.DataBaseName  },
                { "UserName",UserName },
                { "Password",password}
            };
            CreateRunResponse runResponse = client.Pipelines.CreateRunWithHttpMessagesAsync(resourceGroup, dataFactoryName, pipelineName, parameters: parameters).Result.Body;
            Console.WriteLine("Pipeline run ID: " + runResponse.RunId);


            // Console.WriteLine("Checking pipeline run status...");
            int counter = 1;
            PipelineRun pipelineRun = null;
            int maxCounter = Convert.ToInt32(ConfigurationManager.AppSettings["ADFTimeoutCounter"]);

            while (counter < maxCounter)
            {
                pipelineRun = client.PipelineRuns.Get(resourceGroup, dataFactoryName, runResponse.RunId);
                Console.WriteLine("Status: " + pipelineRun.Status);
                if (pipelineRun.Status == "InProgress" || pipelineRun.Status == "Queued")
                {
                    System.Threading.Thread.Sleep(60000);
                    counter++;
                }
                else
                    break;
            }
            String execStatus;
            String StatusMessage = "";
            if (counter == maxCounter)
            {
                client.PipelineRuns.CancelAsync(resourceGroup, dataFactoryName, runResponse.RunId);
                execStatus = "1";
                StatusMessage = "Cancelled long running pipeline";
            }
            else
            {
                RunFilterParameters filterParams = new RunFilterParameters(DateTime.UtcNow.AddMinutes(-10), DateTime.UtcNow.AddMinutes(10));
                ActivityRunsQueryResponse queryResponse = client.ActivityRuns.QueryByPipelineRun(resourceGroup, dataFactoryName, runResponse.RunId, filterParams);
                execStatus = pipelineRun.Status == "Succeeded" ? "0" : "1";

                StatusMessage = pipelineRun.Status == "Succeeded" ? "Export Successful" : queryResponse.Value.First().Output.ToString();
            }

            DataAccessClass db = new DataAccessClass();
            db.updateArchivalStatus(tblArch, inputString, execStatus, StatusMessage, Convert.ToDateTime(pipelineRun.RunStart), Convert.ToDateTime(pipelineRun.RunEnd));
            if (execStatus == "1")
                throw new System.ArgumentException(StatusMessage);
        }
    }
}
