﻿using System;
using System.Collections.Generic;

namespace ArchSolution
{
    public class ConfigTable
    {

        public int TableId { get; set; }
        public string SourceUniqueName { get; set; }
        public string ServerUrl { get; set; }
        public string DataBaseName { get; set; }
        public string DBType { get; set; }



        public string SourceTableName { get; set; }
        public string SourceSchemaName { get; set; }


        public string ArchFrequency { get; set; }
        public int ArchRetentionPeriod { get; set; }
        public string ArchSourceTSField { get; set; }

        public DateTime ArchIntervalLast { get; set; }
        public DateTime dateToUpdate { get; set; }
        public bool isExceptionFound { get; set; }
        public List<string> inputParams { get; set; }



    }
}
